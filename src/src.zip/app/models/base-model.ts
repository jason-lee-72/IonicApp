export class BaseModel {
    errors: any;
    
    constructor () {}

    hasError(field:string) {
        
    }
}